#!/bin/bash

pandoc README.md --pdf-engine=xelatex -o artifact.pdf
